using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jenglmaierManager : MonoBehaviour
{
    //To do:
    //Methoden done
    //If-Statements done
    //Listen done
}
